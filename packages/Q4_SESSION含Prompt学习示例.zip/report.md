# Q4 China Trade Network — Corrected Post-review Re-evaluation

## Executive status

This package is a repaired copy of Git revision `bbc5680c376ad0e387e2374e3469a093cb4c007a`. It reports a **post-review corrected re-evaluation conditional on the supplied 2023-selected 21-node universe**. Four requested implementation defects are fixed and regression-tested. The requested pre-period 2014 X+M node-selection repair remains blocked because the 2014 import ranking request returned HTTP 429. The package therefore does not claim full five-item compliance or a future-selection-bias-free experiment.

The supplied repository, its Git objects, original tag, original results, original report, and original SESSION are preserved under `archive/original/` or `source-provenance/`. No commit or push was made. `SESSION.md` is retained as the real repository record and explicitly states that it is not a complete OpenCode/OpenChamber export.

## Data, graph definition, and reproducibility

The clean snapshot has 21 node IDs, annual rows for 2014–2023, and 4,160 positive reported export rows. Each row represents a directed reported flow

\[
T_{ij,t}=\text{primaryValue}_{ij,t},
\]

from reporter \(i\) to partner \(j\) in year \(t\), in USD. For each reporter-year, the analysis graph retains the ten largest positive export edges. This top-10 rule is an analysis filter; an omitted smaller flow is not asserted to be zero.

The undirected projection used for descriptive structure and node2vec walks is

\[
W_{ij,t}=T_{ij,t}+T_{ji,t}.
\]

Ordinary degree and weighted strength are reported separately. Directed and undirected edge counts and densities are separate quantities. Kruskal MST calculations use the explicit edge cost

\[
d_{ij}=1/\log(1+W_{ij}),
\]

which is an edge cost, not a claim that a complete metric has been established. Betweenness uses the explicitly constructed distance graph. Community migration uses maximum-overlap Hungarian alignment and retains the full old-by-new contingency structure.

The default data command is offline-first:

```text
python data/fetch.py
python code/approach1_q4.py --seed 42 --top-k 10
python code/approach2_q4.py --seed 42 --top-k 10
python code/compare.py
```

The run used the supplied Python 3.13.12 environment and pinned dependencies. A socket-blocked fresh full pipeline completed snapshot verification, Approach A, Approach B, and comparison generation. Snapshot verification reported 2014–2023, 21 nodes, 4,160 rows, and two verified artifacts.

## Data selection limitation and refresh safety

The intended node-selection rule is a pre-period 2014 China total exports-plus-imports ranking, excluding World, China, partner2 aggregates, and `isAggregate` rows. The 2014 export response was fetched and cached at `data/source/china_2014_X_ranking.json` with SHA-256 `f7c9e63e3eb8c832f763fa560ff607bcfa5dbbc0ce34e8bd578095d4e0b2a02`. The import request returned HTTP 429. No identity or proxy substitution was attempted, and no dense retry was made. The status is recorded in `data/source/node_selection_status.json`.

`fetch.py` now validates response `error`, `count`, row length, reporter, period, flow, partner2 and aggregate fields. It fails closed when the response is incomplete and does not hardcode completeness. Refresh builds a staged clean snapshot, validates schema, hashes, duplicate keys, node IDs, self-loops and finite positive amounts, then installs it with rollback protection. The existing supplied snapshot was not replaced.

## Approach A: annual network analytics

Approach A runs all ten years with 21 retained nodes and top-k 10. For each year it records directed and undirected edges, densities, degree-frequency slope, assortativity, connected components, isolated nodes, self-loops, MST forest diagnostics, PageRank, unweighted betweenness on the explicit distance graph, weighted strength, Louvain modularity, and region-proxy diagnostics. Region is not industry ground truth.

The fresh run reported the following representative latest-year values:

| Year | Directed edges | Undirected edges | Components | Communities | Modularity | MST diameter |
|---:|---:|---:|---:|---:|---:|---:|
| 2014 | 210 | 143 | 1 | 4 | 0.225 | 5 |
| 2021 | 210 | 147 | 1 | 4 | 0.181 | 6 |
| 2022 | 200 | 138 | 1 | 4 | 0.187 | 6 |
| 2023 | 200 | 139 | 1 | 3 | 0.194 | 6 |

The full ten-year results are in `results/approach1/q4/metrics.json`; the self-contained figure is `results/approach1/q4/network_evolution.html`.

## Approach B: mathematical protocol

The task is future **directed major-edge formation**. For validation, the history graph is 2021 and target year is 2022. For final evaluation, history is 2022 and target is 2023. An ordered pair \((u,v)\) is positive if it is a top-10 directed edge in the target and absent from the history. A negative is an ordered pair absent from both history and target, sampled at equal count. Missing reporter coverage is unknown, not zero.

Node2vec walks are deliberately run on the historical undirected projection. For a previous walk node \(t\), current node \(v\), and candidate \(x\), the transition multiplier is

\[
\alpha_{pq}(t,x)=
\begin{cases}
1/p,&x=t,\\
1,&(t,x)\in E,\\
1/q,&\text{otherwise}.
\end{cases}
\]

The multiplier is multiplied by the observed undirected edge weight. Walk window is two; walks, length, negative count, epochs and seeds are recorded in metrics.

For each positive context score \(s^+\) and five negative scores \(s^-_r\), the implemented SGNS loss is

\[
\mathcal L=-\operatorname{mean}[\log\sigma(s^+)]
-\operatorname{mean}_b\left[\sum_{r=1}^{5}\log\sigma(-s^-_{br})\right].
\]

The implementation calls the shared `sgns_loss` function, and the regression test calls that same function. Thus a change back to a full negative-tensor mean cannot pass the formula test silently.

The directed score is

\[
s(u,v)=\sigma(z_u^\top Wz_v),
\]

where \(W\) is fitted only on ordered directed history positives and ordered directed history non-edges. `(u,v)` and `(v,u)` are distinct. CN, Adamic–Adar and preferential attachment are explicitly undirected-history baselines and are not presented as directional supervision.

All 36 configurations \(p,q\in\{0.5,1,2\}\), \(d\in\{8,16,32,64\}\) use the same validation pairs. Selection is maximum validation AUC, AP as tie-break, then lower dimension. The final configuration is evaluated once on the final test split.

## Coverage protocol

For each reporter, the expected partner set is

\[
V\setminus\{\text{reporter}\},
\]

not a shared set that includes the reporter itself. Coverage is classified as `full_observed`, `partial`, or `missing_report`. Only `full_observed` reporters are eligible for reliable non-edge labels. History-only observed reporters are used for bilinear W supervision; history-and-target coverage is used only for future evaluation labels.

The actual CSV regression checks 2021 as 21 full reporters, and 2022/2023 as 20 full reporters plus reporter 643 `missing_report`. Final negative pairs contain no reporter 643.

## Fresh measured Approach B results

The socket-blocked fresh full pipeline selected `p=2, q=1, dimension=64`. Validation AUC was `0.694`. The final split contained 14 positives and 14 negatives. The final test metrics were:

| Method | AUC | Average precision |
|---|---:|---:|
| Node2vec + directed bilinear W | 0.632653 | 0.668636 |
| Common neighbors | 0.461735 | 0.471995 |
| Adamic–Adar | 0.471939 | 0.481025 |
| Preferential attachment | 0.408163 | 0.459206 |

The learned model exceeds all three baselines on this small conditional split. Earlier supplied results had already been inspected; this is not a virgin untouched experiment. Metrics state `test_is_untouched: false`, `effective_anchor_year: 2023`, `requested_node_selection_year: 2014`, and `remaining_selection_bias: true`. The overall leakage audit remains false because the node universe is still 2023-selected.

Aligned cluster diagnostics are: ARI versus Louvain `0.891271`, NMI versus Louvain `0.877858`, ARI versus region proxy `0.294096`, and NMI versus region proxy `0.620431`. These are descriptive diagnostics, not industry validation.

## Verification and tests

The final source-coupled suite completed:

```text
Ran 14 tests in 13.358s
OK
```

It covers reporter-specific expected partners, real CSV 2021/2022/2023 coverage, exclusion of reporter 643 from final negatives, metadata order invariance, duplicate/missing/extra ID rejection at the actual clustering entry, ordered directed future pairs, mocked directed W training with reverse edges, the shared SGNS loss function, missing-versus-zero handling, snapshot retrieval failure behavior, ranking count mismatch and aggregate rejection, and repository path restrictions.

The fresh pipeline completed with the corrected source and generated `results/approach1/q4/metrics.json`, `results/approach2/q4/metrics.json`, and `results/comparison.html`. The comparison title is explicitly post-review conditional, not untouched.

## Limitations and administrative status

The 2014 import ranking remains blocked by HTTP 429, so the requested future-free node selection is not complete. Results are conditional on the supplied 2023 universe. The 80/10/10 assignment wording versus chronological validation remains for teacher confirmation. The top-k task recovers major reported relationships; it is not proof of trade formation from zero. Region is a proxy, not industry ground truth. The original complete approved-agent session export, group roster and teacher approval are unavailable and are not fabricated. No commit or push was made.
