# Q4 session record and evidence-backed repair retrospective

**Record type: a supplied historical account plus a retrospective repair record. This is not a complete raw OpenCode/OpenChamber session export.** No missing dialogue, original run timestamps, or terminal-agent identity has been reconstructed. The assignment's complete approved-tool export requirement remains outstanding; a readable work log is not a substitute for it.

## Reading guide and provenance

- **Part A** preserves the body of the session account supplied with source revision `bbc5680c376ad0e387e2374e3469a093cb4c007a`. Statements about its original conversations, local deletions, private repository settings, and commands are claims in that supplied account, not actions independently observed during this documentation update.
- **Part B** records the subsequent review and repair actually observed in this conversation. Narrative descriptions are summaries, not verbatim agent replies or a native tool export. Only explicitly marked user quotations and output excerpts are quotations.
- **Part C** records the documentation update and its new test run. Its timestamp is the actual check time, not a backdated development timestamp.
- **Part D** gives a reusable recording structure and an outstanding-evidence checklist. It does not contain an additional simulated session.
- **Part E — Prompt 学习示例** is a Chinese teaching appendix added separately from the historical record. Its prompts and illustrative replies are examples, not conversations that took place in OpenCode. Actual earlier project results are labeled and linked to their evidence. None of these examples was executed as part of writing the appendix.

The byte-for-byte source record is retained at [archive/original/SESSION.md](archive/original/SESSION.md). Its SHA-256 before this edit was `bd6bbad66a3a68c35e5ef1a4f8b405e1b5f89dbf72ac92dc6740388ff2bede8e`. The source commit, log, tags, and bundle are preserved under [source-provenance](source-provenance/). Git objects can establish the contents and order of stored commits; they do not by themselves prove which assistant produced them or that a conversation export is complete.

**Current scope:** four implementation issues were repaired and measured. The node-universe issue is deferred at the user's request, not resolved. This package still uses the supplied 2023-selected universe. The historical checklist in Part A must not be read as the current acceptance checklist.

## Part A — Imported historical account

The remainder of this part, from `Session metadata` through the original checklist, is preserved from the supplied record. Its exact original introduction is available in the archive. This part describes an earlier version; its metrics and completion claims are not the current repaired results.

## Session metadata

- Date: 2026-11-07, Asia/Shanghai
- Repository: `mqf-q4-main`
- Remote: private GitHub repository under `micheal021`
- Default seed: `42`
- Python target: `3.13`
- Working root: `/Users/xzmini40/Desktop/smy-mqf/mqf-q4-main`
- Destructive operation: the user explicitly requested deletion of the newly created prior Q4 directory; its local directory was removed. GitHub deletion of that prior remote was blocked because the account token lacks the `delete_repo` scope; it was not used for this rebuild.

## Turn 1 — user direction

User asked to inspect the public Cassidy Q2 repository, redo Q4 according to the assignment, and prioritize four review findings: test edges entering training, selecting parameters on test AUC, an inadequate SESSION, and a broken offline reproduction path.

Assistant response: read the assignment specification and the existing Q4 repository; confirmed that the existing code used the full graph for walks and baselines, selected by test AUC, had a milestone summary rather than a complete session export, and called the network from the first README command.

Commands executed:

```text
sed -n '1,520p' /Users/xzmini40/Desktop/smy-mqf/report(1).md
git status --short --branch
git log --oneline --decorate -12
find . -maxdepth 4 -type f
rg -n 'fetch|offline|train|valid|test|AUC|SESSION|edge|negative'
```

The public Cassidy clone was attempted but the GitHub connection timed out. The local `mqf-q2-main` reference repository was then read directly. Its structure informed this repo's short README, `uv run --locked` command, metadata layout, and session format.

## Turn 2 — explicit reset request

User requested that the just-created Q4 work be deleted and rebuilt, while preserving `mqf-q2-main` as the Cassidy reference.

Actions:

```text
gh repo delete micheal021/ap26-q4-trade-network-final --yes
```

GitHub returned HTTP 403 because the current token lacks `delete_repo`. The user-owned local directory was removed with an explicit Python `shutil.rmtree` call. The old `ap26-q4-trade-network` repository and Cassidy's `mqf-q2-main` directory were preserved.

## Milestone 1 — new contract and remote

Created `mqf-q4-main/AGENTS.md` before adding code. The contract fixes the chronological protocol, offline-first fetch behavior, metrics schema, cache policy, and commit discipline.

Commands:

```text
git init -b main
git add AGENTS.md
git commit -m 'chore: add Q4 project contract'
gh repo create micheal021/mqf-q4-main --private
git remote add origin git@github.com-micheal021:micheal021/mqf-q4-main.git
git push -u origin main
```

Commit: `5424c1c chore: add Q4 project contract`.

## Milestone 2 — offline snapshot

Added `.gitignore`, `README.md`, `pyproject.toml`, `uv.lock`, `data/fetch.py`, `data/metadata.json`, and committed clean trade and node snapshots. `fetch.py` now verifies by default and only accesses Comtrade under `--refresh`. The verifier checks SHA-256, row count, CSV columns, year coverage, node count, and self-loops.

Observed offline verification:

```json
{"seed": 42, "offline": true, "years": [2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023], "nodes": 21, "flow_rows": 4160, "artifacts_verified": 2}
```

Commit: `8ccee23 data: add offline-first Comtrade snapshot and verifier`.

## Milestone 3 — implementation and first review

Implemented `code/common.py`, `code/approach1_q4.py`, and `code/approach2_q4.py`.

The first smoke test exposed two implementation issues:

1. A `code/__init__.py` package marker shadowed Python's standard-library `code` module while importing PyTorch. It was removed and committed as `2c75108 chore: remove stdlib-shadowing package marker`.
2. The cumulative history graph could contain fewer non-edges than observed edges. Training-only reconstruction labels now subsample observed positives to keep training labels balanced; this uses no future graph.

The first approach-2 design was then reviewed for methodological fairness. It was changed from an undirected cumulative-history target with configuration-specific negative samples to a directed annual future-edge task with fixed evaluation pairs. All configurations now see exactly the same validation pairs.

Commit: `ac409dc feat: implement leakage-safe Q4 analytics and future links`.

## Milestone 4 — fixed split and formal experiment

The validation and test pair manifests are generated once before the hyperparameter loop. The 36 configurations use the same 2022 validation pairs. The configuration is selected by validation AUC, AP as a tie-break; only then is the selected configuration evaluated on 2023.

The default top-k construction was set to 10 before the final run. With top-10 directed annual edges, both validation and test have 14 positive and 14 negative ordered pairs. The formal commands were:

```text
/Users/xzmini40/Desktop/ap26-q4-trade-network/.venv/bin/python code/approach1_q4.py --seed 42 --top-k 10
/Users/xzmini40/Desktop/ap26-q4-trade-network/.venv/bin/python code/approach2_q4.py --seed 42 --top-k 10 --dimensions 8,16,32,64 --p-values 0.5,1,2 --q-values 0.5,1,2 --epochs 5 --walks-per-node 8 --walk-length 20 --window 2 --negative-count 5
/Users/xzmini40/Desktop/ap26-q4-trade-network/.venv/bin/python code/compare.py
```

Formal output:

```text
Validation learned AUC: 0.806
2023 test learned AUC: 0.592
2023 test CN AUC: 0.469
2023 test AA AUC: 0.487
2023 test PA AUC: 0.408
```

The selected validation configuration is `p=0.5,q=1,d=16`. It was selected before reading the test metrics.

## Final verification checklist

- [x] `AGENTS.md` was committed before code.
- [x] `README.md` is concise and contains one clean-clone command.
- [x] `data/fetch.py` is offline by default; `--refresh` is explicit.
- [x] Metadata records source, date, schema, row counts, bytes, and SHA-256.
- [x] Q4A covers ten years and reports graph statistics, MST, Louvain, centrality, resolution, and migration.
- [x] Q4B uses 2021→2022 validation and 2022→2023 test chronology.
- [x] Walks, baselines, reconstruction scorer, and parameter choice do not use the test year.
- [x] Validation/test pairs are fixed before the hyperparameter sweep.
- [x] Metrics use `{params, metrics, fit_seconds, history}`.
- [x] Plotly files are self-contained and deterministic.
- [x] `compare.py` reads both metrics files and ranks only the untouched test results.
- [x] Multiple milestone commits are pushed to `origin/main`.
- [ ] Exact approved-agent session export: must be generated by the group from the approved OpenCode/OpenChamber session if required; this record does not fabricate that export.


---

## Part B — Observed review and repair, summarized retrospectively

### B1. Scope and review handoff

**Observed user instruction:** “把这个五个关键问题改了”.

The reviewed source version had five identified issues: clustering labels did not follow embedding row IDs; the node universe had been selected using 2023 rankings; the directed prediction scorer had been trained with undirected canonical pairs; missing reporter data could enter negative labels; and the SGNS implementation averaged negative terms where the report specified their sum.

**Decision and scope:** work on an independent copy; retain the source version, original outputs, and original session; change the implementation and rerun affected experiments; do not push, create commits, or move a submission tag. The original test results had already been inspected, so the corrected experiment was described as a post-review re-evaluation rather than a never-seen test.

**Evidence:** [source HEAD](source-provenance/HEAD.txt), [archived outputs](archive/original/), [current report](report.md), and [current metrics](results/approach2/q4/metrics.json).

### B2. Clustering: use node identity rather than row position

**Finding:** the original embeddings followed a sorted node order, while regional metadata used CSV order. Comparing label arrays by position therefore compared different nodes.

**Change:** preserve an explicit `node_order`, map Louvain and region labels by node ID, and validate the node-ID agreement at the clustering entry point. The repaired path does not treat the metadata CSV row order as the embedding order.

**Checks:** the suite reverses metadata order and compares alignment results. It also exercises rejection of malformed metadata with a duplicated ID and a missing expected ID. The test name mentions several ID mismatch cases, but the checked fixture must not be represented as exhaustive coverage of every possible mismatch.

**Evidence:** `validate_node_alignment()` in [common.py](code/common.py), `cluster_agreement()` in [approach2_q4.py](code/approach2_q4.py), and [regression tests](tests/test_five_fixes.py).

**Lesson:** ID correspondence is part of an evaluation contract. A model score is not meaningful until the labels refer to the same objects as the prediction rows.

### B3. Directed prediction: repair the supervision, not just the model name

**Finding:** using canonical undirected pairs discards the reporter-to-partner direction even when the downstream model uses a bilinear matrix.

**Change:** retain the historical undirected projection for node2vec walks and the stated CN/AA/PA baselines, but train the bilinear matrix on ordered directed historical positives and ordered historical non-edges. A later target edge is not used to remove a valid historical negative retrospectively.

**Checks:** a mock exercises the actual bilinear fitting entry point with a `DiGraph` and labels containing reciprocal directed pairs. This proves that the fitting path accepts the intended ordered supervision in that fixture; it is not proof that every real-data label is semantically correct.

**Evidence:** `reconstruction_directed_split()` in [common.py](code/common.py), `fit_bilinear()` in [approach2_q4.py](code/approach2_q4.py), and the stored `training_graph` / `training.bilinear` fields in the current metrics.

**Lesson:** “directed” must be consistent across the task definition, graph representation, labels, and scoring function. A directional formula cannot restore direction already removed from its labels.

### B4. Reporter coverage: missing is not a negative observation

**Finding:** absence of an outgoing report does not establish that all trade links from that reporter are absent.

**Initial repair and follow-up correction:** coverage was first separated into full, partial, and missing observations. Review then caught an error in the expected-partner set: a shared set excluding China was inappropriate for every reporter. A reporter must be evaluated against `all_node_ids - {reporter}`, not a set containing its own ID or omitting another legitimate partner.

The final implementation uses reporter-specific coverage. Historical W training receives reporters qualified using historical data only. A reporter must qualify in both historical and target years to contribute reliable future evaluation labels. Target-year coverage is not fed back into the historical training eligibility rule.

**Observed current snapshot:** the test suite checks full coverage for all reporters in 2021, 20 fully covered reporters in each of 2022 and 2023, and reporter 643 as missing in the latter two years. It checks that stored final negative examples do not use reporter 643. A partial-coverage fixture must not qualify for reliable non-edge labels.

**Evidence:** [tests](tests/test_five_fixes.py), `coverage` and split fields in [B metrics](results/approach2/q4/metrics.json).

**Limit:** complete row coverage inside the supplied node universe does not certify the external data provider's completeness or repair the future-based node-universe selection.

### B5. SGNS: couple the test to the function actually used in training

**Finding:** the original code averaged all negative log terms. With five negative samples, that changes their relative weight compared with summing five terms per positive example.

**Change:** the shared `sgns_loss()` computes the positive batch mean and the per-example negative sum followed by the batch mean. `train_skipgram()` calls this function.

**Review correction:** an early test only evaluated a copied formula. That test could pass even if the training code regressed. The final fixed-tensor test calls the shared loss used by training. Extracting the same expression into a function did not intentionally change the numerical objective.

**Evidence:** `sgns_loss()` and `train_skipgram()` in [approach2_q4.py](code/approach2_q4.py), and the corresponding [test](tests/test_five_fixes.py).

**Lesson:** a regression test should exercise production code, not merely prove that a second copy of the intended formula works.

### B6. Operational failures and corrections that actually occurred

A background launch failed before model execution because its interpreter path omitted a character from the working-directory name. The retained host log contains the diagnostic below; the path has been shortened here, but the error description is not reinterpreted as an experiment failure:

```text
The term '...\.venv\Scripts\python.exe' is not recognized as a name of a cmdlet, function, script file, or executable program.
```

The correction was to use the existing interpreter's verified absolute path. Dependencies were not reinstalled merely to address a misspelled path. A later fresh pipeline completed successfully.

Review also caught an intermediate mismatch between coverage code and already-generated results. Those intermediate results were not accepted as evidence for the new coverage logic. The corrected snapshot validation, A analysis, B sweep and selected evaluation, and comparison were rerun before the final package was produced.

**Evidence basis:** earlier process logs and tool results in this conversation. These paragraphs are concise retrospective descriptions, not a claim that this file contains the full underlying terminal logs or every failed call.

### B7. Node selection: blocked, then explicitly deferred

The intended correction was to select the partner universe from pre-prediction-period data rather than 2023 rankings. A 2014 China export response was acquired and cached. The corresponding import ranking request returned `HTTP 429 Too Many Requests`. No complete 2014 exports-plus-imports ranking or replacement node universe was established.

The current instruction “第五项先不管了” defers that remaining work. No additional external-data request was made for this documentation update. It does not convert the existing node universe into a pre-period universe.

**Evidence:** [node-selection status](data/source/node_selection_status.json) and [cached export response](data/source/china_2014_X_ranking.json).

The current metrics explicitly retain:

```json
{
  "test_is_untouched": false,
  "effective_anchor_year": 2023,
  "requested_node_selection_year": 2014,
  "remaining_selection_bias": true
}
```

### B8. Completed experiment and results retained in the package

The completed earlier run validated the snapshot and executed A, B, and comparison in a socket-blocked environment. Its retrieved process output reported the following selected lines:

```text
Snapshot: 21 nodes, 4160 flow rows, 2 artifacts verified
Q4B validation learned AUC: 0.694
Q4B 2023 test learned AUC: 0.633
```

These are a labeled excerpt/summary of the observed console output, not a complete raw transcript. The structured results were reread during the documentation update and are recorded at [verification.json](evidence/session-enhancement/verification.json).

There are 36 validation configurations. The selected configuration is `p=2`, `q=1`, `dimension=64`; its stored validation AUC is `0.6938775510204082`. The final evaluation contains 14 positive and 14 negative ordered pairs.

| Method | Stored test AUC | Stored test AP |
|---|---:|---:|
| node2vec + directed W | 0.632653 | 0.668636 |
| Common neighbors | 0.461735 | 0.471995 |
| Adamic–Adar | 0.471939 | 0.481025 |
| Preferential attachment | 0.408163 | 0.459206 |

| Selected-run clustering diagnostic | Stored value |
|---|---:|
| ARI versus Louvain | 0.891271 |
| NMI versus Louvain | 0.877858 |
| ARI versus region proxy | 0.294096 |
| NMI versus region proxy | 0.620431 |

The learned scorer exceeds these three baselines on this small, conditional re-evaluation. This observation does not remove node selection bias, establish a never-seen test, or certify that region labels satisfy an industry-label requirement. Current experiment details remain in [report.md](report.md); obsolete pre-repair results remain in the archive.

## Part C — Actual documentation update and new verification

### C1. Work performed in this step

This step expanded the session documentation, preserved the original account, reread current metrics, and reran the existing regression suite. It did not retrain models, change code, modify data, refresh external sources, create Git commits, push, or move a tag.

The evidence-capture check started at `2026-11-07T15:30:17.240263+00:00` and ended at `2026-11-07T15:30:56.971290+00:00`, as recorded by the executing process. These are the actual documentation-check timestamps, not timestamps assigned to earlier review events.

The executed command used the already prepared Python environment. Its portable command portion was:

```text
python -m unittest discover -s tests -v
```

The exact executable path, working directory, return code, and captured output are in [unittest-output.txt](evidence/session-enhancement/unittest-output.txt).

### C2. Actual output and warning

The new test run returned exit code 0 with this terminal summary:

```text
Ran 14 tests in 13.812s

OK
```

It also emitted a `ConvergenceWarning` during the metadata-order test: the toy embedding fixture has repeated points, so KMeans found four distinct clusters while five were requested. This warning is preserved in the captured output rather than removed. It occurred in a regression fixture, not in a new real-data training run during this step.

The suite is focused, not exhaustive. For example, the test named `snapshot_mock_success_and_failure` exercises mocked request/cache behavior; it is not by itself proof of a successful complete external snapshot refresh. Likewise, stored-result checks are not equivalent to rerunning every experiment. The actual test code is included so the coverage can be inspected.

### C3. Evidence index

| Evidence | What it supports | What it does not establish |
|---|---|---|
| [Original SESSION](archive/original/SESSION.md) | Exact supplied historical account | Independent confirmation of all past conversations |
| [Source provenance](source-provenance/) | Source commit/log/tag/bundle inventory | New commits or a new submission tag for the repaired copy |
| [Current B metrics](results/approach2/q4/metrics.json) | Stored configuration, coverage, splits, and scores | Absence of the documented node-selection bias |
| [Node-selection status](data/source/node_selection_status.json) | Recorded incomplete 2014 selection attempt | A completed 2014 X+M selection |
| [New test output](evidence/session-enhancement/unittest-output.txt) | Actual 14-test run, warnings and exit code | A new full A/B training run |
| [Verification summary](evidence/session-enhancement/verification.json) | Check times, metric extraction, source hashes | A native OpenCode export |
| [Documentation-only change audit](evidence/session-enhancement/change-audit.json) | Checked file changes for this update | Approval by the instructor |

## Part D — How to keep a useful session record next time

Use the following structure for each real work block. This is guidance, not another claimed interaction:

| Field | What to record |
|---|---|
| Request | Actual prompt or an explicitly labeled summary; source/export pointer |
| Observation | The inspected file, diagnostic or data condition |
| Decision | What changed and why, including rejected alternatives when observed |
| Action | Exact tool/command or patch reference actually executed |
| Result | Return code and relevant output; leave failures visible |
| Verification | Test/assertion and what it does and does not cover |
| Artifact | Output path and, where useful, checksum |
| Git | Existing real commit hash, or explicitly “uncommitted”; never fill a missing hash |
| Remaining work | Blocked items, missing evidence, and assumptions requiring confirmation |

A short factual record that includes a failed run and its actual correction is more useful for learning than a perfectly smooth dialogue that cannot be checked. Record precise times only when they come from logs; use ordered steps when exact timing is unavailable. Preserve the native tool export separately if the assignment requires it.

### Current acceptance checklist — supersedes Part A for the repaired copy

- [x] Original account preserved byte-for-byte in the archive.
- [x] Repaired implementation and current experiment metrics available.
- [x] New 14-test documentation check completed; warning retained.
- [x] Import ranking limitation and remaining 2023-universe bias disclosed.
- [x] No new commit, push, or tag claimed for this repair/documentation step.
- [ ] Full raw approved-tool session export supplied.
- [ ] Node universe rebuilt from verified pre-period X+M ranking; currently deferred.
- [ ] Teacher acceptance of chronological splitting and region proxy established.
- [ ] Group identity and contribution evidence supplied where required.

This file is suitable for studying how to document an actual debugging and validation process. Its increased detail does not turn it into the missing raw export or certify fulfillment of that separate requirement.

---

## Part E — Prompt 学习示例：从第一次提问到验证结果

> **性质：教学附录，不是历史会话。** 以下“你可以这样问”和“助手示意回复”是为学习而编写的例子，没有在 OpenCode 中实际发生。标为“项目已有实测参照”的数字来自前文证据，不能当成运行示例 Prompt 后产生的新结果。本轮只补充文档，没有启动 OpenCode、运行这些提示词、重训模型或修改 Git。
>
> 主报告与原过程记录保持英文，本教学附录按你的学习需要使用中文。第五项节点选择继续暂缓，不在练习中静默启动抓取。

### E0. 先理解：你输入的是任务，助手回复不是执行凭证

你不需要先学一套特殊语法。核心是把“希望它做什么”写成可检查的任务。把下面的 Prompt 粘贴到已打开的 OpenCode 项目会话即可；其中的代码路径均相对于项目根目录。

若你还没打开项目，可以在已经安装、配置好 OpenCode 的电脑上，进入**项目练习副本**的目录后参考以下命令。本附录没有替你安装、登录或确认本机可运行：

```text
opencode --help
opencode
```

文档也列出非交互形式：

```text
opencode run "只读取 README.md 和 AGENTS.md，解释项目结构，不修改任何文件。"
```

命令参考：[OpenCode CLI 参考页](https://www.opencode.asia/cli/)。这是本次检索到的文档站点，不将其声称为已经核实归属的官方站；具体子命令和参数以你安装版本的本地帮助为准。本附录不依赖特定模式快捷键或界面布局。

**先守住三个边界：**

- 练习用副本，不要直接在唯一一份作业目录中尝试大改。
- 提示词写“不修改”有助于表达意图，但不替代工具的权限控制；授权执行或写入前仍应查看动作内容。不要为了省事关闭全部权限确认。
- “我准备运行”“我认为应该通过”“测试已通过”是三个不同状态。最后一句应对应实际命令、退出码和输出，而不是只看助手的措辞。

### E1. 通用写法：六个要素，不必堆角色设定

**目标 + 上下文 + 操作范围 + 禁止事项 + 验收条件 + 返回格式。**

```text
目标：我想完成什么。
上下文：相关文件、已知问题、当前限制。
范围：本轮允许读取、修改、运行哪些内容。
禁止：不要顺手做哪些事情。
验收：用什么测试、对照或证据判断完成。
输出：最后按什么结构交付。
```

例如，“帮我优化代码”没有说明“优化”指正确性、速度还是结构。对这个 Q4，更有效的是“只修节点对齐，不改模型；元数据换序后聚类结果不变”。你也不需要写“你是世界顶尖专家”；明确边界和验收通常比这种身份设定更有用。

下面八组示例按实际工作顺序组织。它们不是一口气发给助手的一条巨型指令：先拿到上一阶段结果，再发下一阶段。当前项目已有修复，练习时应先检查，避免要求助手重复改已经正确的代码。

### 示例 1｜先读懂项目，不让助手上来就改

**你可以这样问（教学 Prompt）：**

```text
我第一次接触这个 Q4 项目。请先只读检查，不修改文件、不安装依赖、不联网。

先读 README.md、AGENTS.md、pyproject.toml，查看 code/ 的入口，
再查看 report.md 和 results/ 中的指标结构。

请用中文回答：
1. A、B 两部分分别解决什么问题？
2. 数据经过哪些处理，哪些文件负责？
3. 训练、验证、最终评估分别使用什么时间范围？
4. 当前哪些结果是已有文件中的结果，而不是你刚运行得到的？
5. 哪些限制不能通过运行成功来消除？

每个结论给出文件路径或字段依据。不确定就标注待核实。
```

**助手示意回复（教学示例，非实际输出）：**

> 我会先画清数据和代码的对应关系，不运行实验。结构说明会区分报告宣称、代码实现和结果文件；若三者冲突，单独列出，而不是默认报告正确。

**对应结果应是什么：**一份有文件依据的项目导航，不应出现未执行却宣称“验证通过”。例如，它应能指出 `data/fetch.py`、A/B 脚本和 `code/compare.py` 各自的职责。

**不满意时追问：**

```text
你只复述了 README。请把“报告说什么”和“源码实际怎么做”分两列，
对时间切分和数据覆盖各检查一处关键实现。
```

**学到的技巧：**在不了解项目时先限制为只读，降低助手过早修改的风险。

### 示例 2｜把模糊要求变成小范围计划

**你可以这样问（教学 Prompt）：**

```text
先不要改代码。请检查以下四项是否已经修复：
节点 ID 对齐、有向 W 的监督标签、缺报不作负例、SGNS 负项求和。

只检查 code/common.py、code/approach2_q4.py 和 tests/test_five_fixes.py。
第五项节点选择暂缓，不新增数据请求，不更新 Git。

请逐项给出：当前实现、潜在问题、最小修改位置、回归测试、是否需要重训。
已经正确的部分明确写“不改”，不要为了产生补丁重写代码。
最后给出推荐的执行顺序，等我选择具体项再修改。
```

**助手示意回复（教学示例，非实际输出）：**

> 我会把实现检查与测试覆盖检查分开。实现正确但测试薄弱时，优先补测试，不改变模型。涉及损失或监督标签的修改通常需要重新评估；纯文档说明不应自动触发重训。

**对应结果应是什么：**一个逐项计划，能够说明“为什么改”“为什么不改”和需要付出的运行成本，而不是直接生成整仓库替代品。

**不满意时追问：**

```text
请指出哪一项真的需要改变输出数值，哪一项只影响说明或测试。
没有具体问题证据的重构先从计划里删除。
```

**学到的技巧：**先让助手提出可检查的计划，再按项授权实施，避免一句“都优化下”引发失控修改。

### 示例 3｜节点对齐：给出不变量，而不是只说“修 Bug”

**你可以这样问（教学 Prompt）：**

```text
请在练习副本中检查 cluster_agreement() 的输入对齐。
如果已经正确，保持实现，只补缺失测试；否则做最小修复。

验收条件：
- embeddings 每一行通过显式 node_order 对应节点 ID；
- Louvain 与 region 标签按这个 ID 顺序取值，不使用 CSV 原行序；
- 重排元数据不改变同一批向量的 ARI/NMI；
- 缺失、重复、额外 ID 分别用独立测试验证，不能靠默认标签补齐；
- 测试直接调用生产函数。

不修改嵌入训练参数、划分和数据。请返回补丁范围、实际测试命令、结果和剩余风险。
```

**助手示意回复（教学示例，非实际输出）：**

> 我会先追踪向量行号到节点 ID 的映射，再检查标签生成。验收使用同一批向量、只重排元数据；如果两次指标不同，就是对齐逻辑问题，不能通过重新训练掩盖。

**对应结果应是什么：**元数据换序的不变性测试，以及三种 ID 错误的独立失败测试。这里没有预设“ARI 必须变高”：正确对齐后高低都可能发生。

**项目已有实测参照，不是示例运行结果：**当前选定模型的 `ARI vs Louvain = 0.891271`、`NMI vs Louvain = 0.877858`，见 [verification.json](evidence/session-enhancement/verification.json) 的 `cluster_agreement`。这些数值来自已存实验，不能承诺你下一次训练一定相同，也不能仅凭它们证明对齐正确。

**不满意时追问：**

```text
请不要只给指标。展示测试中 node_order 与 metadata 顺序如何不同，
并说明断言为什么能在错位实现下失败。
```

### 示例 4｜SGNS：让数学公式和执行路径同时受约束

**你可以这样问（教学 Prompt）：**

```text
请检查 SGNS 损失是否符合：
正样本项按 batch 求平均；每个正样本的 K 个负样本项先求和，再按 batch 求平均。

如果需要修改，将公式集中到 sgns_loss()，训练和测试都调用它。
用固定 logits 写数值对照，并对照错误的“整个负项张量直接 mean”实现。
说明 batch 维和 K 维分别在哪里，为什么不能混用。

不要仅修改报告公式来迁就错误实现。先完成小测试，不自动启动全量训练。
```

**助手示意回复（教学示例，非实际输出）：**

> 两种写法通常不是单纯对整个损失乘同一个常数：负项权重相对于正项发生变化。我会分别标明张量维度，并测试训练实际调用的损失函数，而不是复制一份公式作为测试。

**对应结果应是什么：**可追踪的 `train_skipgram → sgns_loss` 调用、固定张量对照，以及对负项权重变化的解释。若随后确实改变了训练目标，需要另行运行实验，不能保留旧指标假装新代码已验证。

**不满意时追问：**

```text
如果我把生产损失改回负项 mean，你的测试会失败吗？
请说明它调用哪个函数；不要只给一段与生产代码没有关系的公式。
```

### 示例 5｜有向监督与缺报：分别约束训练和评估

**你可以这样问（教学 Prompt）：**

```text
请检查有向 W 的训练标签与未来标签生成，先只读给出问题。

必须满足：
1. 训练正边保留 reporter→partner 顺序，不能用 min/max 排序去掉方向；
2. 每个 reporter 的预期伙伴是全部节点减去自身；
3. missing/partial reporter 不能被当成可靠非边；
4. 历史训练资格只看历史覆盖；评估资格才看历史与目标两年覆盖；
5. 不因为某条边未来出现，就从历史负标签中偷偷删除它。

请给一个很小的独立测试用例说明(1,2)与(2,1)为何不同，
再核对实际 CSV 的覆盖状态。小用例只能进 tests，不能混入真实实验数据。
```

**助手示意回复（教学示例，非实际输出）：**

> 我会分别列出历史监督函数和评估标签函数的输入。目标年覆盖可用于判断标签是否已观测，但不能回头决定训练时哪些 reporter 被允许参与。

**对应结果应是什么：**有向标签证据、逐 reporter 的覆盖检查、以及训练路径不使用未来覆盖的验证。仅写一个 `directional=True` 字段不算证明。

**项目已有实测参照：**已有测试检查了缺报 reporter 643 不作为最终负例的起点。该检查只覆盖当前快照及相应断言，不等于外部数据源完整性认证。证据见 [tests/test_five_fixes.py](tests/test_five_fixes.py) 和 [test output](evidence/session-enhancement/unittest-output.txt)。

**不满意时追问：**

```text
请沿 main → fit_and_evaluate → fit_bilinear 追踪 reporter 名单。
如果只修了 split 函数，而调用方仍传入未来覆盖集合，请指出来。
```

### 示例 6｜遇到报错：给上下文，不要只说“再试试”

**你可以这样问（教学 Prompt 模板；方括号由你填真实内容）：**

```text
刚才运行失败。请先定位，不要重复运行同一个失败命令。

实际工作目录：[粘贴本机路径]
实际命令：[粘贴原命令]
退出码：[原输出中的退出码]
原始报错：[粘贴完整关键段，去掉密钥]

请区分：解释器路径问题、依赖问题、代码异常、数据校验失败。
优先做最小诊断，不重装整个环境，不改数据、不重新抓取。
如果失败发生在报告生成，而模型结果已写出，只重跑受影响步骤。
最后给出原因、最小修复、实际复验结果。
```

**助手示意回复（教学示例，非实际输出）：**

> 我会先确定 Python 是否已经启动。若 shell 连解释器都没有找到，修改训练算法没有意义；若模型完成而比较页失败，也不应每次重新训练。

**对应结果应是什么：**原因与错误证据对应，只执行必要的修复步骤。若失败仍未解决，结果应是明确阻塞，不是把失败解释成“已经好了”。

**项目真实案例参照：**Part B6 已记录一次解释器绝对路径拼写错误。它不是模型训练失败。这是过去的实际事件，不表示本示例又运行并遇到了相同错误。

**不满意时追问：**

```text
你提议重装依赖，但原报错是否真的发生在 import 阶段？
请给出支持这个判断的原文，否则先检查路径和启动状态。
```

### 示例 7｜实测与报告：要求证据，不指定想要的分数

**你可以这样问（教学 Prompt，执行前应确认资源允许）：**

```text
请使用项目已配置的环境先跑回归测试，保留 stdout/stderr 和退出码。
若通过，再按已固定配置运行 A、B 和比较，不新增参数搜索。
只用验证集选参，选定后评估最终目标；第五项节点选择继续暂缓，不联网取数。

每个阶段报告：未运行/运行中/成功/失败、输出文件、关键警告。
最后从实际 JSON 提取指标，核对 report.md 与 HTML 的数字。
不要为了让 AUC 好看而改随机种子、样本或基线定义。
已有结果看过，要明确是修正后复评，而不是新的未触碰测试。
```

**助手示意回复（教学示例，非实际输出）：**

> 我会先检查依赖与命令是否匹配项目。报告只使用实际返回的指标；低于基线也照实写。如果第五项暂缓，结果必须保留节点选择限制，运行成功不能消除这项偏差。

**对应结果应是什么：**真正的阶段状态和文件，而不是预先填好的成功数字。警告与失败必须可见。不要因为回复“测试通过”就推断所有方法论要求也通过。

**项目已有实测参照，不是本示例执行结果：**

| 项目 | 证据中的既有结果 |
|---|---|
| 上一次文档核对时的测试 | 14 项，退出码 0 |
| 既有模型测试 AUC | 0.632653 |
| 既有模型测试 AP | 0.668636 |
| 节点选择前视限制 | 仍存在；第五项暂缓 |

证据：[verification.json](evidence/session-enhancement/verification.json)、[unittest-output.txt](evidence/session-enhancement/unittest-output.txt)。本次添加教学附录没有重新运行这些测试或模型。

**不满意时追问：**

```text
请区分“读取旧 results 得到的数值”和“本轮重新执行得到的数值”。
给出本轮命令、退出码和产物对应关系；没有运行就明确说没有运行。
```

### 示例 8｜记录与导出：原始数据和整理稿分开

**你可以这样问（教学 Prompt）：**

```text
我已经完成这一轮真实操作。请整理本轮的请求、修改文件、实际命令、报错、
测试与产物，缺少原始日志的部分注明没有记录，不补写历史对话。

另外先只读查看当前 OpenCode 版本和 session/export 的本地帮助，
告诉我怎样识别这轮真实会话并导出到一个新文件，避免覆盖 SESSION.md。
不要自动导出别的会话、公开分享、提交 Git 或上传文件。
```

**助手示意回复（教学示例，非实际输出）：**

> 我会先核对本地帮助和会话列表。你确认具体会话后，再导出它的原始数据。Markdown 整理稿另存，不能把整理稿叫作完整原始导出；导出前还要检查敏感字段。

**对应结果应是什么：**真实会话标识的核对方法、导出步骤，以及原始导出和人工整理稿的区别。没有真实会话时，正确结果是“目前没有可导出的该轮记录”，不是生成一个看似完整的 JSON。

**命令学习参考，以下没有在本轮执行：**

```text
opencode --version
opencode session --help
opencode session list
opencode export --help
```

参考页说明 `opencode export [sessionID]` 导出 JSON。方括号是帮助中的可选参数表示法；实际使用时应填入列表中核对过的真实会话 ID，不能把方括号或随手编的 ID 当参数。输出应保存到新的原始记录文件，具体保存方式按本机 shell 与本地帮助处理。

导出文件的完整性、敏感数据处理和课程要求仍需核对；存在一个文件不自动等于满足所有提交要求。

**不满意时追问：**

```text
请列出整理稿中哪些句子能对应原始输出，哪些只是总结。
没有出处的“已经执行”改成待确认，不要添加推测的时间或调用记录。
```

### E2. 入门练习顺序与快速自检

建议先做示例 1 的只读理解，再做示例 2 的计划检查；熟悉项目后，选示例 3—5 中的一项，在副本中练习最小修改。遇到错误用示例 6；确实准备承担运行成本时再用示例 7；真实操作后用示例 8 保存记录。

发送前自检：

- 是否说清楚了这一轮只做什么？
- 是否给了相关文件，而不是让助手猜？
- 是否区分了“先分析”和“允许修改/运行”？
- 是否禁止了不需要的联网、提交、重训和顺手重构？
- 是否有会在错误实现下失败的验收条件？
- 是否要求助手说明已执行、未执行和无法确认的部分？

**最重要的一句：Prompt 的目标不是让助手说出漂亮的完成报告，而是让它的行动和结果可以核查。** 教学示意回复只展示合适的沟通方式，不能替代实际工具结果。
