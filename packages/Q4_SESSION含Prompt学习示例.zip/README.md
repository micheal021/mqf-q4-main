# MQF Advanced Programming — Q4 fixed package
This package runs annual China-partner trade analytics and chronological directed major-edge formation.
Default data verification is offline; all model selection uses 36 validation configurations and one frozen final test.
The intended node selector is a pre-period 2014 China total X+M ranking; this delivery records the import-response block and does not claim a rebuilt 2014-complete snapshot.
Python 3.13.12 with the supplied exact environment is sufficient; use `uv run` or the supplied interpreter.
PowerShell: `python data/fetch.py; python code/approach1_q4.py --seed 42 --top-k 10; python code/approach2_q4.py --seed 42 --top-k 10; python code/compare.py`.
Tests: `python -m unittest discover -s tests -v`.
The directed bilinear scorer uses ordered historical positives/non-edges; node2vec walks and heuristic baselines use an explicitly documented undirected projection.
Missing reporter coverage is unknown and excluded from labels, never converted to zero.
Old outputs are archived under `archive/original` and excluded from active comparison.
