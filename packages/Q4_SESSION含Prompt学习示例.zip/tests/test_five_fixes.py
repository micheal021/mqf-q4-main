"""Focused regression tests for the four repaired items and blocked selector."""
from __future__ import annotations
import json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import networkx as nx
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'));sys.path.insert(0,str(ROOT))
from approach2_q4 import cluster_agreement, fit_bilinear, sgns_loss
from common import coverage_matrix,future_directed_split,load_nodes,repo_path
from data import fetch
class FourFixTests(unittest.TestCase):
 def test_metadata_shuffle_does_not_change_cluster_alignment(self):
  nodes=load_nodes();order=sorted(row['node_code'] for row in nodes);graph=nx.path_graph(order);embeddings=np.eye(len(order),3,dtype=float);first=cluster_agreement(embeddings,graph,order,nodes,42);second=cluster_agreement(embeddings,graph,order,list(reversed(nodes)),42);self.assertEqual(first['node_order'],second['node_order']);self.assertEqual(first['ari_vs_louvain'],second['ari_vs_louvain'])
 def test_cluster_rejects_duplicate_missing_extra_ids(self):
  nodes=load_nodes();order=sorted(row['node_code'] for row in nodes);bad=list(nodes[:-1])+[dict(nodes[-2])]
  with self.assertRaises(ValueError):cluster_agreement(np.eye(len(order),3),nx.path_graph(order),order,bad,42)
 def test_directional_pairs_preserve_order(self):
  history=nx.DiGraph();history.add_nodes_from([1,2,3]);history.add_edge(1,2);target=nx.DiGraph();target.add_nodes_from([1,2,3]);target.add_edges_from([(2,1),(1,3)]);result=future_directed_split(history,target,{1:True,2:True,3:True},{1:True,2:True,3:True},np.random.default_rng(1));self.assertIn((2,1),result['positive']);self.assertIn((1,3),result['positive'])
 def test_missing_reporter_is_not_negative(self):
  history=nx.DiGraph();history.add_nodes_from([1,2,3]);history.add_edge(1,2);target=nx.DiGraph();target.add_nodes_from([1,2,3]);target.add_edge(3,1);result=future_directed_split(history,target,{1:True,2:True,3:False},{1:True,2:True,3:False},np.random.default_rng(1));self.assertNotIn((3,1),result['positive']);self.assertNotIn((3,2),result['negative'])
 def test_coverage_uses_reporter_specific_partners(self):
  nodes=list(range(21));edges=[]
  for reporter in nodes:
   for partner in nodes:
    if partner!=reporter:edges.append({'year':2021,'reporter_code':reporter,'partner_code':partner,'trade_value_usd':1.0})
  coverage=coverage_matrix(edges,[2021],nodes,nodes);self.assertTrue(all(item['status']=='full_observed' for item in coverage['2021'].values()));self.assertEqual(coverage['2021']['0']['expected_partner_count'],20)
 def test_partial_reporter_not_reliable(self):
  coverage=coverage_matrix([{'year':2022,'reporter_code':1,'partner_code':2,'trade_value_usd':1.0}],[2022],[1],[1,2,3]);self.assertEqual(coverage['2022']['1']['status'],'partial');self.assertFalse(coverage['2022']['1']['reliable_for_nonedge_labels'])
 def test_full_reporter_has_explicit_coverage(self):
  edges=[{'year':2022,'reporter_code':1,'partner_code':partner,'trade_value_usd':1.0} for partner in (2,3)];self.assertEqual(coverage_matrix(edges,[2022],[1],[1,2,3])['2022']['1']['status'],'full_observed')
 def test_real_csv_coverage_and_final_negatives(self):
  edges=[]
  with (ROOT/'data'/'clean'/'trade_flows.csv').open(newline='',encoding='utf-8') as handle:
   import csv
   edges=list(csv.DictReader(handle))
  nodes=[int(row['node_code']) for row in load_nodes()]
  coverage=coverage_matrix(edges,[2021,2022,2023],nodes,nodes)
  self.assertTrue(all(item['status']=='full_observed' for item in coverage['2021'].values()))
  self.assertEqual(sum(item['status']=='full_observed' for item in coverage['2022'].values()),20)
  self.assertEqual(sum(item['status']=='full_observed' for item in coverage['2023'].values()),20)
  self.assertEqual(coverage['2022']['643']['status'],'missing_report')
  self.assertEqual(coverage['2023']['643']['status'],'missing_report')
  metrics=json.loads((ROOT/'results'/'approach2'/'q4'/'metrics.json').read_text(encoding='utf-8'))['metrics']
  for pair in metrics['test']['future_split']['negative']:
   self.assertNotEqual(pair[0],643)
 def test_sgns_formula_is_used_by_training_function(self):
  positive=torch.tensor([.2,-.4]);negative=torch.tensor([[.1,-.2,.3],[-.1,.4,-.5]]);corrected=sgns_loss(positive,negative);old=-torch.nn.functional.logsigmoid(positive).mean()-torch.nn.functional.logsigmoid(-negative).mean();self.assertNotAlmostEqual(float(corrected),float(old));self.assertAlmostEqual(float(corrected),2.869767,places=4)
 def test_bilinear_uses_ordered_directed_labels(self):
  history=nx.DiGraph();history.add_nodes_from([1,2,3]);history.add_edges_from([(1,2),(2,1),(2,3)]);embeddings=np.eye(3,dtype=np.float32);seen={}
  def split(graph,reporters,rng):
   self.assertIsInstance(graph,nx.DiGraph);seen['pairs']=True;return {'train_positive':[(1,2),(2,1)],'train_negative':[(1,3),(3,1)]}
  with patch('approach2_q4.reconstruction_directed_split',side_effect=split):fit_bilinear(embeddings,[1,2,3],history,[1,2,3],7)
  self.assertTrue(seen['pairs'])
 def test_repo_path_rejects_external_output(self):
  with self.assertRaises(ValueError):repo_path(Path(tempfile.gettempdir())/'outside-q4')
 def test_missing_data_is_not_zero(self):
  with self.assertRaises(ValueError):fetch.rows_for({'status':'ok'})
  self.assertEqual(fetch.value({'primaryValue':0}),0.0)
 def test_snapshot_mock_success_and_failure(self):
  with tempfile.TemporaryDirectory(dir=ROOT/'tests') as directory:
   target=Path(directory)/'response.json';payload={'data':[{'partnerCode':1,'primaryValue':2}]}
   class Response:
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def read(self):return json.dumps(payload).encode()
   with patch.object(fetch,'urlopen',return_value=Response()):self.assertEqual(fetch.request_json({'period':2014},target,0),payload)
   target.unlink()
   with patch.object(fetch,'urlopen',side_effect=OSError('offline')):
    with self.assertRaises(RuntimeError):fetch.request_json({'period':2014},target,0)
   self.assertFalse(target.exists())
 def test_ranking_response_rejects_count_and_aggregate(self):
  payload={'count':1,'data':[{'reporterCode':156,'period':'2014','flowCode':'X','partner2Code':0,'isAggregate':False,'partnerCode':842}]};fetch.validate_ranking_response(payload,'X');payload['count']=2
  with self.assertRaises(ValueError):fetch.validate_ranking_response(payload,'X')
  payload['count']=1;payload['data'][0]['isAggregate']=True
  with self.assertRaises(ValueError):fetch.validate_ranking_response(payload,'X')
if __name__=='__main__':unittest.main()
