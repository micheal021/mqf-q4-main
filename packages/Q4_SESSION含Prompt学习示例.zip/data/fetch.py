"""Offline-first snapshot validation and explicit Comtrade refresh support."""
from __future__ import annotations
import argparse,csv,hashlib,json,os,shutil,tempfile,time
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.error import HTTPError
from urllib.request import Request,urlopen
import numpy as np
ROOT=Path(__file__).resolve().parents[1]; RAW=ROOT/'data'/'raw'; CLEAN=ROOT/'data'/'clean'; METADATA=ROOT/'data'/'metadata.json'; API='https://comtradeapi.un.org/public/v1/preview/C/A/HS'; CHINA=156
COUNTRY_NAMES={32:'Argentina',36:'Australia',40:'Austria',56:'Belgium',76:'Brazil',124:'Canada',152:'Chile',156:'China',170:'Colombia',191:'Croatia',203:'Czechia',208:'Denmark',246:'Finland',250:'France',251:'France',276:'Germany',344:'Hong Kong',356:'India',360:'Indonesia',364:'Iran',372:'Ireland',376:'Israel',380:'Italy',392:'Japan',398:'Kazakhstan',410:'South Korea',458:'Malaysia',484:'Mexico',528:'Netherlands',554:'New Zealand',566:'Nigeria',578:'Norway',586:'Pakistan',604:'Peru',608:'Philippines',616:'Poland',620:'Portugal',634:'Qatar',643:'Russia',682:'Saudi Arabia',702:'Singapore',710:'South Africa',724:'Spain',752:'Sweden',756:'Switzerland',764:'Thailand',792:'Türkiye',804:'Ukraine',826:'United Kingdom',834:'Tanzania',842:'United States',860:'Uzbekistan',704:'Vietnam'}
REGIONS={'East Asia':{156,344,392,410,704},'South Asia':{356,586},'Southeast Asia':{360,458,608,702,764},'Europe':{40,56,191,203,208,246,250,276,372,380,528,616,620,643,724,752,756,804,826},'North America':{124,484,842},'South America':{32,76,152,170,604},'Middle East':{364,376,634,682},'Africa':{566,710,834},'Central Asia':{398,860},'Oceania':{36,554}}
def parse_years(value):
 if ':' in value:
  start,end=(int(x) for x in value.split(':',1));
  if end<start: raise ValueError('year range end must not precede start')
  return list(range(start,end+1))
 years=[int(x.strip()) for x in value.split(',') if x.strip()]
 if not years: raise ValueError('no years supplied')
 return years
def country_name(code): return COUNTRY_NAMES.get(code,f'Partner {code}')
def country_region(code): return next((r for r,s in REGIONS.items() if code in s),'Other')
def sha256(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def atomic_json(path,payload):
 path.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
 try:
  with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(payload,f,ensure_ascii=False,indent=2)
  os.replace(tmp,path)
 except Exception:
  Path(tmp).unlink(missing_ok=True);raise
def rows_for(payload):
 if 'data' not in payload or not isinstance(payload['data'],list):raise ValueError('response missing list-valued data field')
 return payload['data']
def request_json(params,target,pause=.12):
 if target.exists():payload=json.loads(target.read_text(encoding='utf-8'));rows_for(payload);return payload
 url=API+'?'+urlencode(params).replace('%2C',',');last=None
 for attempt in range(4):
  try:
   req=Request(url,headers={'User-Agent':'mqf-q4-main/1.0'})
   with urlopen(req,timeout=60) as response:payload=json.loads(response.read().decode('utf-8'))
   rows_for(payload);atomic_json(target,payload);time.sleep(pause);return payload
  except HTTPError as error:
   last=error
   if error.code == 429:
    retry_after = error.headers.get('Retry-After')
    raise RuntimeError(f'Comtrade rate limited; Retry-After={retry_after!r}; do not retry in this run') from error
   if attempt < 3:
    time.sleep(2**attempt)
  except Exception as error:
   last=error
   if attempt<3:time.sleep(2**attempt)
 raise RuntimeError(f'Comtrade request failed: {url}') from last
def value(row):
 raw=row.get('primaryValue')
 if raw is None:return 0.0
 try:return float(raw)
 except (TypeError,ValueError):return 0.0
def validate_ranking_response(payload,flow):
 rows=rows_for(payload);errors=[]
 if payload.get('error') not in (None,'',[]):errors.append(f'API error field: {payload.get("error")}')
 if not isinstance(payload.get('count'),int):errors.append('missing integer count')
 elif payload['count']!=len(rows):errors.append(f'count {payload["count"]} != rows {len(rows)}')
 if not rows:errors.append('empty ranking response')
 for row in rows:
  if int(row.get('reporterCode',-1))!=CHINA or str(row.get('period'))!='2014' or row.get('flowCode')!=flow:errors.append('row reporter/period/flow mismatch');break
  if int(row.get('partner2Code',0) or 0)!=0:errors.append('partner2 aggregate row present');break
 if any(bool(row.get('isAggregate')) for row in rows):errors.append('isAggregate row present')
 if errors:raise ValueError('incomplete ranking response: '+'; '.join(errors))
 return {'count':len(rows),'flow':flow,'truncated':False,'api_error':False,'aggregate_rows':0}
def rank_partners_from_payloads(export_payload,import_payload,top_partners):
 """Rank validated 2014 X+M responses; reject incomplete/truncated/aggregate data."""
 validate_ranking_response(export_payload,'X');validate_ranking_response(import_payload,'M');scores={}
 for payload in (export_payload,import_payload):
  for row in rows_for(payload):
   partner=int(row.get('partnerCode',-1))
   if partner<=0 or partner==CHINA or int(row.get('partner2Code',0) or 0)!=0 or bool(row.get('isAggregate')):continue
   scores[partner]=scores.get(partner,0.0)+value(row)
 if len(scores)<top_partners:raise ValueError(f'only {len(scores)} valid partners for {top_partners}')
 return [code for code,_ in sorted(scores.items(),key=lambda item:(-item[1],item[0]))[:top_partners]]
def select_2014_nodes(top_partners=20):
 params={'reporterCode':CHINA,'period':2014,'cmdCode':'TOTAL','partner2Code':0,'customsCode':'C00','maxRecords':500};paths={flow:RAW/f'china_2014_{flow}_ranking.json' for flow in ('X','M')};payloads={};checks={}
 for flow,path in paths.items():payloads[flow]=request_json({**params,'flowCode':flow},path);checks[flow]=validate_ranking_response(payloads[flow],flow)
 nodes=[CHINA,*rank_partners_from_payloads(payloads['X'],payloads['M'],top_partners)]
 return nodes,{'selection_year':2014,'rule':'top 20 primaryValue X+M; exclude partnerCode 0/World, China, partner2 and isAggregate rows','top_partners':top_partners,'node_codes':nodes,'requests':{flow:{**params,'flowCode':flow} for flow in paths},'response_files':{flow:path.relative_to(ROOT).as_posix() for flow,path in paths.items()},'response_sha256':{flow:sha256(path) for flow,path in paths.items()},'response_checks':checks,'source_date':datetime.now(timezone.utc).isoformat(),'complete_response_verified':all(c['count']>0 and not c['truncated'] and not c['api_error'] for c in checks.values())}
def write_csv(path,rows,fields):
 with path.open('w',newline='',encoding='utf-8') as f:csv.DictWriter(f,fieldnames=fields).writeheader();
 with path.open('a',newline='',encoding='utf-8') as f:csv.DictWriter(f,fieldnames=fields).writerows(rows)
def build_snapshot(years,nodes,pause):
 node_set=set(nodes);out=[]
 for year in years:
  for reporter in nodes:
   payload=request_json({'reporterCode':reporter,'period':year,'flowCode':'X','cmdCode':'TOTAL','partnerCode':','.join(str(x) for x in nodes),'partner2Code':0,'customsCode':'C00'},RAW/f'reporter_{reporter}_{year}_X.json',pause)
   for row in rows_for(payload):
    partner=int(row.get('partnerCode',-1))
    if partner in node_set and partner!=reporter:out.append({'year':year,'reporter_code':reporter,'partner_code':partner,'trade_value_usd':value(row),'flow':'exports','source':'UN Comtrade preview API'})
 return out
def metadata_for(flow_path,node_path,years,nodes,selection):
 artifacts={}
 for path in (flow_path,node_path):
  with path.open(newline='',encoding='utf-8') as f:table=list(csv.DictReader(f))
  artifacts[path.relative_to(ROOT).as_posix()]={'sha256':sha256(path),'bytes':path.stat().st_size,'rows':len(table),'columns':list(table[0]) if table else []}
 return {'source':API,'retrieved_at_utc':datetime.now(timezone.utc).isoformat(),'years':years,'top_partners':len(nodes)-1,'anchor_year':2014,'flow_definition':'Annual reported exports among China and a 2014-preselected partner set.','node_count':len(nodes),'edge_rows':artifacts['data/clean/trade_flows.csv']['rows'],'offline_default':True,'node_selection':selection,'artifacts':artifacts}
def read_flow_rows(path):
 with path.open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def read_node_rows(path):
 with path.open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def validate_rows(rows,nodes):
 node_ids={int(r['node_code']) for r in nodes};seen=set()
 for row in rows:
  reporter=int(row['reporter_code']);partner=int(row['partner_code']);amount=float(row['trade_value_usd']);key=(int(row['year']),reporter,partner)
  if reporter not in node_ids or partner not in node_ids or reporter==partner:raise ValueError('foreign node ID or self-loop')
  if not np.isfinite(amount) or amount<=0 or key in seen:raise ValueError('duplicate or invalid flow row')
  seen.add(key)
def verify_snapshot():
 required=(CLEAN/'trade_flows.csv',CLEAN/'node_metadata.csv',METADATA);missing=[p.relative_to(ROOT).as_posix() for p in required if not p.exists()]
 if missing:raise FileNotFoundError(f'offline snapshot incomplete: {missing}')
 metadata=json.loads(METADATA.read_text(encoding='utf-8'));artifacts=metadata.get('artifacts');expected={'data/clean/trade_flows.csv','data/clean/node_metadata.csv'}
 if not isinstance(artifacts,dict) or set(artifacts)!=expected:raise ValueError('manifest must contain exactly both clean artifacts')
 for relative,info in artifacts.items():
  path=ROOT/relative
  if not path.exists() or not isinstance(info.get('sha256'),str) or len(info['sha256'])!=64:raise ValueError(f'missing artifact or SHA-256: {relative}')
  if sha256(path)!=info['sha256']:raise ValueError(f'checksum mismatch: {relative}')
  with path.open(newline='',encoding='utf-8') as f:table=list(csv.DictReader(f))
  if len(table)!=info.get('rows') or (table and list(table[0])!=info.get('columns')):raise ValueError(f'schema/row-count mismatch: {relative}')
 rows=read_flow_rows(CLEAN/'trade_flows.csv');nodes=read_node_rows(CLEAN/'node_metadata.csv');validate_rows(rows,nodes);years=sorted({int(r['year']) for r in rows})
 if years!=sorted(metadata.get('years',[])) or len(nodes)!=int(metadata.get('node_count',-1)):raise ValueError('metadata coverage mismatch')
 return {'offline':True,'years':years,'nodes':len(nodes),'flow_rows':len(rows),'artifacts_verified':len(artifacts),'node_selection_status':metadata.get('node_selection',{}).get('complete_response_verified','unknown')}
def validate_staged_snapshot(staging):
 metadata_path=staging/'metadata.json';flow_path=staging/'clean'/'trade_flows.csv';node_path=staging/'clean'/'node_metadata.csv'
 if not all(p.exists() for p in (metadata_path,flow_path,node_path)):raise ValueError('staged snapshot incomplete')
 metadata=json.loads(metadata_path.read_text(encoding='utf-8'));artifacts=metadata.get('artifacts');expected={'data/clean/trade_flows.csv','data/clean/node_metadata.csv'}
 if not isinstance(artifacts,dict) or set(artifacts)!=expected:raise ValueError('staged manifest invalid')
 for relative,info in artifacts.items():
  path=staging/relative.removeprefix('data/')
  if len(info.get('sha256',''))!=64 or sha256(path)!=info['sha256']:raise ValueError(f'staged checksum mismatch: {relative}')
 rows=read_flow_rows(flow_path);nodes=read_node_rows(node_path);validate_rows(rows,nodes);return {'years':sorted({int(r['year']) for r in rows}),'nodes':len(nodes),'rows':len(rows)}
def install_staged_snapshot(staging):
 validate_staged_snapshot(staging);backup=Path(tempfile.mkdtemp(prefix='q4-snapshot-backup-',dir=ROOT));live=[CLEAN/'trade_flows.csv',CLEAN/'node_metadata.csv',METADATA]
 try:
  for p in live:
   if p.exists():shutil.copy2(p,backup/p.name)
  CLEAN.mkdir(parents=True,exist_ok=True);shutil.copy2(staging/'clean'/'trade_flows.csv',CLEAN/'trade_flows.csv');shutil.copy2(staging/'clean'/'node_metadata.csv',CLEAN/'node_metadata.csv');shutil.copy2(staging/'metadata.json',METADATA);return verify_snapshot()
 except Exception:
  for p in live:
   if (backup/p.name).exists():shutil.copy2(backup/p.name,p)
  raise
 finally:shutil.rmtree(backup,ignore_errors=True)
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--years',default='2014:2023');parser.add_argument('--top-partners',type=int,default=20);parser.add_argument('--pause',type=float,default=.12);parser.add_argument('--seed',type=int,default=42);parser.add_argument('--refresh',action='store_true');args=parser.parse_args()
 if not args.refresh:print(json.dumps({'seed':args.seed,**verify_snapshot()},indent=2));return
 years=parse_years(args.years);nodes,selection=select_2014_nodes(args.top_partners);rows=build_snapshot(years,nodes,args.pause);staging=Path(tempfile.mkdtemp(prefix='q4-refresh-',dir=ROOT))
 try:
  (staging/'clean').mkdir();flow=staging/'clean'/'trade_flows.csv';node=staging/'clean'/'node_metadata.csv';write_csv(flow,rows,['year','reporter_code','partner_code','trade_value_usd','flow','source']);write_csv(node,[{'node_code':c,'node_name':country_name(c),'region':country_region(c),'is_china':int(c==CHINA)} for c in nodes],['node_code','node_name','region','is_china']);atomic_json(staging/'metadata.json',metadata_for(flow,node,years,nodes,selection));print(json.dumps(install_staged_snapshot(staging),indent=2))
 finally:shutil.rmtree(staging,ignore_errors=True)
if __name__=='__main__':main()
