"""Shared, chronology-aware graph and data utilities for Q4."""
from __future__ import annotations

import csv
import json
import random
from pathlib import Path
from time import perf_counter
from typing import Iterable

import networkx as nx
import numpy as np
import torch
from scipy.optimize import linear_sum_assignment

ROOT = Path(__file__).resolve().parents[1]


def repo_path(path: Path, root: Path = ROOT) -> Path:
    """Resolve a path and reject paths outside the repository."""
    resolved = (path if path.is_absolute() else root / path).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as error:
        raise ValueError(f"path must stay inside repository: {resolved}") from error
    return resolved


def set_seed(seed: int) -> np.random.Generator:
    """Seed all stochastic libraries used by the project."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    return np.random.default_rng(seed)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def load_nodes(path: Path | None = None) -> list[dict]:
    """Load nodes and reject duplicate IDs or malformed IDs."""
    path = path or ROOT / "data" / "clean" / "node_metadata.csv"
    rows = []
    for row in read_csv(path):
        rows.append({
            **row,
            "node_code": int(row["node_code"]),
            "is_china": int(row["is_china"]),
        })
    ids = [row["node_code"] for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError("node metadata contains duplicate node IDs")
    if not ids:
        raise ValueError("node metadata is empty")
    return rows


def explicit_node_order(nodes: list[dict], expected: Iterable[int] | None = None) -> list[int]:
    """Return a deterministic ID order and reject missing/extra expected IDs."""
    order = sorted(row["node_code"] for row in nodes)
    if expected is not None and set(order) != set(int(node) for node in expected):
        raise ValueError("metadata node IDs do not match the expected node set")
    return order


def load_edges(path: Path | None = None) -> list[dict]:
    path = path or ROOT / "data" / "clean" / "trade_flows.csv"
    rows = []
    for row in read_csv(path):
        parsed = {
            **row,
            "year": int(row["year"]),
            "reporter_code": int(row["reporter_code"]),
            "partner_code": int(row["partner_code"]),
            "trade_value_usd": float(row["trade_value_usd"]),
        }
        if parsed["reporter_code"] == parsed["partner_code"]:
            raise ValueError(f"self-loop in edge row: {parsed}")
        if not np.isfinite(parsed["trade_value_usd"]) or parsed["trade_value_usd"] <= 0:
            raise ValueError(f"invalid trade value: {parsed}")
        rows.append(parsed)
    return rows


def coverage_matrix(edges: list[dict], years: Iterable[int], reporters: Iterable[int], expected_partners: Iterable[int] | None = None) -> dict[str, dict[str, dict]]:
    """Classify reporter-year coverage against every other node ID.

    The expected partner set is reporter-specific: a reporter is never expected
    to report a self-loop. Missing values remain unknown rather than zero.
    """
    reporter_ids = [int(reporter) for reporter in reporters]
    all_node_ids = set(int(partner) for partner in (expected_partners if expected_partners is not None else reporter_ids))
    result = {}
    for year in years:
        year_result = {}
        for reporter in reporter_ids:
            expected_for_reporter = all_node_ids - {reporter}
            observed_partners = {
                int(row["partner_code"])
                for row in edges
                if int(row["year"]) == int(year) and int(row["reporter_code"]) == reporter
            }
            observed_count = len(observed_partners & expected_for_reporter)
            if observed_count == 0:
                status = "missing_report"
            elif observed_count == len(expected_for_reporter):
                status = "full_observed"
            else:
                status = "partial"
            year_result[str(reporter)] = {
                "status": status,
                "row_count": sum(int(row["year"]) == int(year) and int(row["reporter_code"]) == reporter for row in edges),
                "observed_partner_count": observed_count,
                "expected_partner_count": len(expected_for_reporter),
                "reliable_for_nonedge_labels": status == "full_observed",
            }
        result[str(year)] = year_result
    return result


def validate_node_alignment(node_order: Iterable[int], nodes: list[dict]) -> list[int]:
    """Validate that embedding rows and metadata describe exactly one ID each."""
    order = [int(node) for node in node_order]
    metadata_ids = [int(row["node_code"]) for row in nodes]
    if len(order) != len(set(order)) or len(metadata_ids) != len(set(metadata_ids)):
        raise ValueError("duplicate node IDs in embedding order or metadata")
    if set(order) != set(metadata_ids) or len(order) != len(metadata_ids):
        raise ValueError("embedding node_order and metadata node IDs do not match")
    return order


def annual_graph(edges: list[dict], nodes: list[dict], year: int, top_k: int = 10) -> nx.DiGraph:
    """Build one directed top-k annual graph while retaining every node."""
    node_order = explicit_node_order(nodes)
    graph = nx.DiGraph(year=year)
    graph.add_nodes_from(node_order)
    year_edges = [row for row in edges if row["year"] == year and row["trade_value_usd"] > 0]
    selected = []
    for reporter in node_order:
        outgoing = [
            row for row in year_edges
            if row["reporter_code"] == reporter and row["partner_code"] != reporter
        ]
        selected.extend(
            sorted(outgoing, key=lambda row: (-row["trade_value_usd"], row["partner_code"]))[:top_k]
        )
    for row in selected:
        graph.add_edge(row["reporter_code"], row["partner_code"], weight=row["trade_value_usd"])
    if nx.number_of_selfloops(graph):
        raise ValueError(f"self-loop in annual graph {year}")
    return graph


def undirected_graph(graph: nx.DiGraph) -> nx.Graph:
    """Make the documented undirected projection by summing reciprocal weights."""
    result = nx.Graph(year=graph.graph.get("year"))
    result.add_nodes_from(graph.nodes)
    for left, right, attributes in graph.edges(data=True):
        if left == right:
            raise ValueError("self-loop cannot enter undirected projection")
        weight = float(attributes.get("weight", 0.0))
        if result.has_edge(left, right):
            result[left][right]["weight"] += weight
        else:
            result.add_edge(left, right, weight=weight)
    return result


def history_graph(edges: list[dict], nodes: list[dict], end_year: int, top_k: int) -> nx.Graph:
    """Union annual undirected projections through an explicitly dated cutoff."""
    result = nx.Graph(history_end=end_year)
    result.add_nodes_from(explicit_node_order(nodes))
    years = sorted({row["year"] for row in edges if row["year"] <= end_year})
    for year in years:
        for left, right, attrs in undirected_graph(annual_graph(edges, nodes, year, top_k)).edges(data=True):
            result.add_edge(left, right, weight=result.get_edge_data(left, right, {}).get("weight", 0.0) + attrs["weight"])
    return result


def edge_pairs(graph: nx.Graph) -> list[tuple[int, int]]:
    """Canonicalize only undirected graph edges; never use for directed labels."""
    return sorted((min(int(left), int(right)), max(int(left), int(right))) for left, right in graph.edges)


def directed_pairs(graph: nx.DiGraph) -> list[tuple[int, int]]:
    """Preserve reporter-to-partner order for directed supervision."""
    return sorted((int(left), int(right)) for left, right in graph.edges)


def all_pairs(nodes: Iterable[int]) -> list[tuple[int, int]]:
    ordered = sorted(int(node) for node in nodes)
    return [(left, right) for left in ordered for right in ordered if left != right]


def sample_equal(values: list[tuple[int, int]], count: int, rng: np.random.Generator) -> list[tuple[int, int]]:
    if len(values) < count:
        raise ValueError(f"only {len(values)} candidates for {count} negatives")
    if count == 0:
        return []
    indices = rng.choice(len(values), size=count, replace=False)
    return [values[int(index)] for index in indices]


def future_directed_split(
    history: nx.DiGraph,
    target: nx.DiGraph,
    history_coverage: dict[int, bool],
    target_coverage: dict[int, bool],
    rng: np.random.Generator,
) -> dict[str, list[tuple[int, int]]]:
    """Build directed labels only for reporters observed in both stages.

    A missing reporter is unknown, not a negative observation. Target edges in
    history are deliberately allowed as historical non-edges for the task.
    """
    reliable = sorted(node for node in history.nodes if history_coverage.get(node, False) and target_coverage.get(node, False))
    history_edges = {(int(left), int(right)) for left, right in history.edges}
    target_edges = {(int(left), int(right)) for left, right in target.edges}
    positives = sorted(
        (left, right) for left, right in target_edges - history_edges if left in reliable
    )
    candidates = [(left, right) for left in reliable for right in history.nodes if left != right]
    negatives = sorted(set(candidates) - history_edges - target_edges)
    negatives = sample_equal(negatives, len(positives), rng)
    rng.shuffle(positives)
    rng.shuffle(negatives)
    return {"positive": positives, "negative": negatives}


def reconstruction_directed_split(history: nx.DiGraph, observed_reporters: Iterable[int], rng: np.random.Generator) -> dict[str, list[tuple[int, int]]]:
    """Balance ordered training labels only for historically observed reporters."""
    reliable = sorted(int(node) for node in observed_reporters if node in history)
    positives = sorted((int(left), int(right)) for left, right in history.edges if left in reliable)
    candidates = [(left, right) for left in reliable for right in history.nodes if left != right]
    negatives = sorted(set(candidates) - set(positives))
    count = min(len(positives), len(negatives))
    positives = [positives[int(i)] for i in rng.choice(len(positives), size=count, replace=False)]
    negatives = sample_equal(negatives, count, rng)
    rng.shuffle(positives)
    rng.shuffle(negatives)
    return {"train_positive": positives, "train_negative": negatives}


def region_labels(nodes: list[dict]) -> dict[int, str]:
    return {row["node_code"]: row.get("region", "Unknown") for row in nodes}


def align_communities(previous: dict[int, int], current: dict[int, int], nodes: list[int]) -> dict[int, int]:
    old_ids = sorted(set(previous.values()))
    new_ids = sorted(set(current.values()))
    matrix = np.zeros((len(old_ids), len(new_ids)), dtype=int)
    for i, old_id in enumerate(old_ids):
        for j, new_id in enumerate(new_ids):
            matrix[i, j] = sum(previous[node] == old_id and current[node] == new_id for node in nodes)
    rows, cols = linear_sum_assignment(-matrix)
    mapping = {new_ids[col]: old_ids[row] for row, col in zip(rows, cols)}
    next_id = max(old_ids, default=-1) + 1
    for new_id in new_ids:
        mapping.setdefault(new_id, next_id)
        next_id += 1
    return mapping


def jsonable(value):
    if isinstance(value, dict):
        return {str(key): jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    return value


def write_metrics(path: Path, params: dict, metrics: dict, fit_seconds: float, history: dict) -> None:
    path = repo_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"params": jsonable(params), "metrics": jsonable(metrics), "fit_seconds": float(fit_seconds), "history": jsonable(history)}
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def save_plot(figure, path: Path, div_id: str) -> None:
    path = repo_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    figure.write_html(str(path), include_plotlyjs=True, full_html=True, div_id=div_id)


def timed(function, *args, **kwargs):
    start = perf_counter()
    value = function(*args, **kwargs)
    return value, perf_counter() - start
