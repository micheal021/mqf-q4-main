"""Q4B: chronological future directed-edge prediction with five repairs."""
from __future__ import annotations

import argparse
import math
import time
from pathlib import Path

import networkx as nx
import numpy as np
import plotly.graph_objects as go
import torch
from rich.console import Console
from rich.table import Table
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, average_precision_score, normalized_mutual_info_score, roc_auc_score

from common import ROOT, annual_graph, coverage_matrix, directed_pairs, future_directed_split, load_edges, load_nodes, reconstruction_directed_split, repo_path, region_labels, save_plot, set_seed, undirected_graph, validate_node_alignment, write_metrics

BASELINES = ("common_neighbors", "adamic_adar", "preferential_attachment")


def biased_walk(graph, start, length, p, q, rng):
    """Generate one node2vec walk on the explicitly documented undirected projection."""
    walk = [start]
    while len(walk) < length:
        current = walk[-1]
        neighbors = sorted(graph.neighbors(current))
        if not neighbors:
            break
        previous = walk[-2] if len(walk) > 1 else None
        weights = []
        for neighbor in neighbors:
            if previous is None:
                bias = 1.0
            elif neighbor == previous:
                bias = 1.0 / p
            elif graph.has_edge(previous, neighbor):
                bias = 1.0
            else:
                bias = 1.0 / q
            weights.append(max(float(graph[current][neighbor].get("weight", 1.0)), 1e-12) * bias)
        probabilities = np.asarray(weights, dtype=float)
        probabilities /= probabilities.sum()
        walk.append(int(rng.choice(neighbors, p=probabilities)))
    return walk


def walk_pairs(graph, p, q, rng, walks_per_node, length, window):
    """Build skip-gram contexts from the history-only undirected graph."""
    nodes = sorted(graph.nodes)
    pairs = []
    for _ in range(walks_per_node):
        order = list(nodes)
        rng.shuffle(order)
        for start in order:
            walk = biased_walk(graph, int(start), length, p, q, rng)
            for center, source in enumerate(walk):
                for offset in range(1, window + 1):
                    for position in (center - offset, center + offset):
                        if 0 <= position < len(walk):
                            pairs.append((source, walk[position]))
    return pairs


def sgns_loss(positive: torch.Tensor, negative: torch.Tensor) -> torch.Tensor:
    """Return the documented SGNS loss with a per-example negative-term sum."""
    return -torch.nn.functional.logsigmoid(positive).mean() - torch.nn.functional.logsigmoid(-negative).sum(dim=1).mean()


def train_skipgram(pairs, nodes, dimension, seed, epochs, negative_count):
    """Train SGNS with the five negative log terms summed per positive pair."""
    if not pairs:
        raise ValueError("training graph produced no walk contexts")
    torch.manual_seed(seed)
    index = {node: i for i, node in enumerate(nodes)}
    sources = torch.tensor([index[left] for left, _ in pairs], dtype=torch.long)
    targets = torch.tensor([index[right] for _, right in pairs], dtype=torch.long)
    embedding = torch.nn.Embedding(len(nodes), dimension)
    context = torch.nn.Embedding(len(nodes), dimension)
    torch.nn.init.xavier_uniform_(embedding.weight)
    torch.nn.init.zeros_(context.weight)
    optimizer = torch.optim.Adam([*embedding.parameters(), *context.parameters()], lr=0.03)
    generator = torch.Generator().manual_seed(seed + 11)
    history = []
    for _ in range(epochs):
        order = torch.randperm(len(sources), generator=generator)
        losses = []
        for start in range(0, len(order), 512):
            batch = order[start : start + 512]
            source_vector = embedding(sources[batch])
            target_vector = context(targets[batch])
            positive = (source_vector * target_vector).sum(dim=1)
            negative_targets = torch.randint(len(nodes), (len(batch), negative_count), generator=generator)
            negative = torch.einsum("bd,bnd->bn", source_vector, context(negative_targets))
            loss = sgns_loss(positive, negative)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach()))
        history.append(float(np.mean(losses)))
    return embedding.weight.detach().cpu().numpy(), history


def fit_bilinear(embeddings, nodes, history_directed, observed_reporters, seed):
    """Fit W on ordered directed history positives and ordered history non-edges."""
    rng = np.random.default_rng(seed)
    labels = reconstruction_directed_split(history_directed, observed_reporters, rng)
    pairs = labels["train_positive"] + labels["train_negative"]
    index = {node: i for i, node in enumerate(nodes)}
    left = torch.tensor([index[a] for a, _ in pairs])
    right = torch.tensor([index[b] for _, b in pairs])
    y = torch.tensor([1.0] * len(labels["train_positive"]) + [0.0] * len(labels["train_negative"]))
    matrix = torch.nn.Parameter(torch.eye(embeddings.shape[1]))
    tensor = torch.tensor(embeddings, dtype=torch.float32)
    optimizer = torch.optim.Adam([matrix], lr=0.05)
    losses = []
    for _ in range(160):
        score = torch.einsum("bi,ij,bj->b", tensor[left], matrix, tensor[right])
        loss = torch.nn.functional.binary_cross_entropy_with_logits(score, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        losses.append(float(loss.detach()))
    return matrix.detach().numpy(), {"epochs": 160, "initial_loss": losses[0], "final_loss": losses[-1], "training_positive": len(labels["train_positive"]), "training_negative": len(labels["train_negative"]), "directional": True}


def scores(embeddings, matrix, nodes, pairs):
    """Score ordered pairs; (u,v) and (v,u) remain distinct."""
    index = {node: i for i, node in enumerate(nodes)}
    output = []
    for left, right in pairs:
        raw = embeddings[index[left]] @ matrix @ embeddings[index[right]]
        output.append(float(1.0 / (1.0 + math.exp(-float(np.clip(raw, -50, 50))))))
    return np.asarray(output)


def evaluate(pairs, values):
    labels = np.asarray([1] * len(pairs["positive"]) + [0] * len(pairs["negative"]))
    return {"auc": float(roc_auc_score(labels, values)), "average_precision": float(average_precision_score(labels, values)), "positive_count": len(pairs["positive"]), "negative_count": len(pairs["negative"])}


def heuristic_scores(graph, pairs, method):
    """Undirected-projection baselines, explicitly separate from directional W."""
    if method == "common_neighbors":
        values = {(a, b): len(list(nx.common_neighbors(graph, a, b))) for a, b in pairs}
    elif method == "adamic_adar":
        values = {(a, b): score for a, b, score in nx.adamic_adar_index(graph, pairs)}
    elif method == "preferential_attachment":
        values = {(a, b): score for a, b, score in nx.preferential_attachment(graph, pairs)}
    else:
        raise ValueError(f"unknown baseline: {method}")
    return np.asarray([float(values.get(pair, 0.0)) for pair in pairs])


def cluster_agreement(embeddings, history, node_order, nodes, seed):
    """Align every cluster label to the same explicit embedding node order."""
    validate_node_alignment(node_order, nodes)
    if embeddings.shape[0] != len(node_order):
        raise ValueError("embedding row count does not match node_order")
    groups = nx.community.louvain_communities(history, weight="weight", seed=seed)
    louvain = {node: i for i, group in enumerate(sorted(groups, key=lambda group: min(group))) for node in group}
    labels = KMeans(n_clusters=max(2, len(groups)), random_state=seed, n_init=10).fit_predict(embeddings)
    regions = region_labels(nodes)
    region_ids = {name: i for i, name in enumerate(sorted(set(regions.values())))}
    louvain_vector = [louvain[node] for node in node_order]
    region_vector = [region_ids.get(regions.get(node, "Unknown"), -1) for node in node_order]
    return {"kmeans_k": max(2, len(groups)), "node_order": node_order, "ari_vs_louvain": float(adjusted_rand_score(louvain_vector, labels)), "nmi_vs_louvain": float(normalized_mutual_info_score(louvain_vector, labels)), "ari_vs_region_proxy": float(adjusted_rand_score(region_vector, labels)), "nmi_vs_region_proxy": float(normalized_mutual_info_score(region_vector, labels))}


def fit_and_evaluate(history, history_directed, future, nodes, observed_reporters, p, q, dimension, seed, args):
    """Fit one candidate using only one dated history graph and evaluate one target split."""
    rng = np.random.default_rng(seed)
    contexts = walk_pairs(history, p, q, rng, args.walks_per_node, args.walk_length, args.window)
    embeddings, loss_history = train_skipgram(contexts, nodes, dimension, seed, args.epochs, args.negative_count)
    matrix, bilinear_history = fit_bilinear(embeddings, nodes, history_directed, observed_reporters, seed + 19)
    pairs = future["positive"] + future["negative"]
    learned = evaluate(future, scores(embeddings, matrix, nodes, pairs))
    baselines = {name: evaluate(future, heuristic_scores(history, pairs, name)) for name in BASELINES}
    return {"learned": learned, "baselines": baselines, "future_split": future, "training_graph": {"history_end": history.graph.get("year"), "nodes": history.number_of_nodes(), "undirected_edges": history.number_of_edges(), "directed_edges": history_directed.number_of_edges(), "supervision": "ordered directed history pairs"}, "training": {"walk_contexts": len(contexts), "p": p, "q": q, "dimension": dimension, "skipgram_loss": loss_history, "bilinear": bilinear_history, "seed": seed}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--dimensions", default="8,16,32,64")
    parser.add_argument("--p-values", default="0.5,1,2")
    parser.add_argument("--q-values", default="0.5,1,2")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--walks-per-node", type=int, default=8)
    parser.add_argument("--walk-length", type=int, default=20)
    parser.add_argument("--window", type=int, default=2)
    parser.add_argument("--negative-count", type=int, default=5)
    parser.add_argument("--out", type=Path, default=ROOT / "results" / "approach2" / "q4")
    args = parser.parse_args()
    set_seed(args.seed)
    started = time.perf_counter()
    nodes_meta = load_nodes()
    node_order = sorted(row["node_code"] for row in nodes_meta)
    edges = load_edges()
    years = sorted({row["year"] for row in edges})
    coverage = coverage_matrix(edges, years, node_order, node_order)
    validation_history_directed = annual_graph(edges, nodes_meta, 2021, args.top_k)
    validation_target_directed = annual_graph(edges, nodes_meta, 2022, args.top_k)
    test_history_directed = annual_graph(edges, nodes_meta, 2022, args.top_k)
    test_target_directed = annual_graph(edges, nodes_meta, 2023, args.top_k)
    validation_history = undirected_graph(validation_history_directed)
    test_history = undirected_graph(test_history_directed)
    validation_history_observed = {node: coverage["2021"][str(node)]["status"] == "full_observed" for node in node_order}
    test_history_observed = {node: coverage["2022"][str(node)]["status"] == "full_observed" for node in node_order}
    validation_target_observed = {node: coverage["2022"][str(node)]["status"] == "full_observed" for node in node_order}
    test_target_observed = {node: coverage["2023"][str(node)]["status"] == "full_observed" for node in node_order}
    validation_coverage = {node: validation_history_observed[node] and validation_target_observed[node] for node in node_order}
    test_coverage = {node: test_history_observed[node] and test_target_observed[node] for node in node_order}
    validation_future = future_directed_split(validation_history_directed, validation_target_directed, validation_coverage, validation_coverage, np.random.default_rng(args.seed + 2022))
    test_future = future_directed_split(test_history_directed, test_target_directed, test_coverage, test_coverage, np.random.default_rng(args.seed + 2023))
    if len(validation_future["positive"]) != len(validation_future["negative"]) or len(test_future["positive"]) != len(test_future["negative"]):
        raise ValueError("future labels must remain balanced after excluding unknown reporters")
    dimensions = [int(value) for value in args.dimensions.split(",")]
    p_values = [float(value) for value in args.p_values.split(",")]
    q_values = [float(value) for value in args.q_values.split(",")]
    validation_sweep = {}
    validation_rows = []
    for p in p_values:
        for q in q_values:
            for dimension in dimensions:
                key = f"p={p:g},q={q:g},d={dimension}"
                result = fit_and_evaluate(validation_history, validation_history_directed, validation_future, node_order, [node for node, ok in validation_history_observed.items() if ok], p, q, dimension, args.seed + dimension + int(p * 100) + int(q * 1000), args)
                validation_sweep[key] = {"validation": result["learned"], "baselines": result["baselines"], "training": result["training"]}
                validation_rows.append((result["learned"]["auc"], result["learned"]["average_precision"], -dimension, p, q, dimension))
    selected = max(validation_rows)
    selected_config = {"p": selected[3], "q": selected[4], "dimension": selected[5], "selection_rule": "maximum validation AUC, AP then lower dimension; test metrics not inspected"}
    final = fit_and_evaluate(test_history, test_history_directed, test_future, node_order, [node for node, ok in test_history_observed.items() if ok], selected[3], selected[4], selected[5], args.seed + 9000, args)
    contexts = walk_pairs(test_history, selected[3], selected[4], np.random.default_rng(args.seed + 9000), args.walks_per_node, args.walk_length, args.window)
    embeddings, _ = train_skipgram(contexts, node_order, selected[5], args.seed + 9000, args.epochs, args.negative_count)
    final["cluster_agreement"] = cluster_agreement(embeddings, test_history, node_order, nodes_meta, args.seed)
    ordered = sorted(validation_sweep.items(), key=lambda item: item[1]["validation"]["auc"], reverse=True)
    top = ordered[:12]
    figure = go.Figure([go.Bar(x=[key for key, _ in top], y=[item["validation"]["auc"] for _, item in top], name="validation AUC")])
    figure.update_layout(title="Q4B validation sweep (selection only)", xaxis_title="Configuration", yaxis_title="Validation AUC")
    save_plot(figure, args.out / "validation_sweep.html", "q4b_validation_sweep")
    metrics = {"task": {"type": "future_directed_trade_edge_formation", "protocol_status": "post-review corrected re-evaluation", "validation_target_year": 2022, "test_target_year": 2023, "candidate_negatives": "ordered pairs absent from history and target; reporter coverage required"}, "chronology": {"validation_history_year": 2021, "test_history_year": 2022, "test_is_untouched": False, "effective_anchor_year": 2023, "requested_node_selection_year": 2014, "node_selection_status": "blocked: 2014 import ranking HTTP 429", "remaining_selection_bias": True}, "coverage": coverage, "coverage_used_for_validation": validation_coverage, "coverage_used_for_test": test_coverage, "split_manifest": {"validation": validation_future, "test": test_future}, "selected_configuration": selected_config, "validation_sweep": validation_sweep, "test": final, "leakage_audit": {"walk_graph_validation": "2021 annual undirected projection only", "walk_graph_test": "2022 annual undirected projection only", "bilinear_supervision": "ordered directed history positives/non-edges", "parameter_selection_metric": "validation_auc", "test_used_for_selection": False, "same_validation_pairs_for_all_configurations": True, "overall_leakage_free": False, "remaining_selection_bias": "node universe selected from 2023 because 2014 X+M selector was blocked"}}
    params = {"seed": args.seed, "top_k": args.top_k, "dimensions": dimensions, "p_values": p_values, "q_values": q_values, "epochs": args.epochs, "walks_per_node": args.walks_per_node, "walk_length": args.walk_length, "window": args.window, "negative_count": args.negative_count, "node_order": node_order, "coverage_policy": "exclude missing reporter from labels; missing is unknown, not zero"}
    write_metrics(args.out / "metrics.json", params, metrics, time.perf_counter() - started, {"validation_top": [{"configuration": key, "auc": item["validation"]["auc"]} for key, item in top], "selected_configuration": selected_config})
    table = Table(title="Q4B future-edge prediction")
    for column in ["Stage", "Learned AUC", "CN", "AA", "PA"]:
        table.add_column(column)
    table.add_row("Validation", f"{selected[0]:.3f}", "—", "—", "—")
    table.add_row("2023 test", f"{final['learned']['auc']:.3f}", f"{final['baselines']['common_neighbors']['auc']:.3f}", f"{final['baselines']['adamic_adar']['auc']:.3f}", f"{final['baselines']['preferential_attachment']['auc']:.3f}")
    Console().print(table)


if __name__ == "__main__":
    main()
